package com.edu.controller;

import com.edu.data.AppData;
import com.edu.data.FileHandler;
import com.edu.model.Student;
import com.edu.model.Course;
import com.edu.model.Prediction;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.stage.FileChooser;

import java.io.*;
import java.util.ArrayList;

public class ImportController {

    // ================= STUDENTS =================
    @FXML
    public void importStudents() {

        File file = chooseFile();
        if (file == null) return;

        int count = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            br.readLine(); // skip header

            String line;
            while ((line = br.readLine()) != null) {

                String[] p = line.split(",");

                if (p.length < 6) continue;

                AppData.studentList.add(new Student(
                        p[0], p[1], p[2], p[3],
                        Double.parseDouble(p[4]),
                        p[5]
                ));

                count++;
            }

            FileHandler.saveStudents(AppData.studentList);
            refreshUI();

            showSuccess("Students imported: " + count);

        } catch (Exception e) {
            e.printStackTrace();
            showError("Student import failed");
        }
    }

    // ================= COURSES =================
    @FXML
    public void importCourses() {

        File file = chooseFile();
        if (file == null) return;

        int count = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            br.readLine();

            String line;
            while ((line = br.readLine()) != null) {

                String[] p = line.split(",");

                if (p.length < 5) continue;

                AppData.courseList.add(new Course(
                        p[0], p[1], p[2],
                        Integer.parseInt(p[3]),
                        Double.parseDouble(p[4])
                ));

                count++;
            }

            FileHandler.saveCourses(AppData.courseList);
            refreshUI();

            showSuccess("Courses imported: " + count);

        } catch (Exception e) {
            e.printStackTrace();
            showError("Course import failed");
        }
    }

    // ================= PREDICTIONS =================
    @FXML
    public void importPredictions() {

        File file = chooseFile();
        if (file == null) return;

        int count = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            br.readLine();

            String line;
            while ((line = br.readLine()) != null) {

                String[] p = line.split(",");

                if (p.length < 5) continue;

                AppData.predictionList.add(new Prediction(
                        p[0], p[1], p[2],
                        Double.parseDouble(p[3]),
                        p[4]
                ));

                count++;
            }

            FileHandler.savePredictions(AppData.predictionList);
            refreshUI();

            showSuccess("Predictions imported: " + count);

        } catch (Exception e) {
            e.printStackTrace();
            showError("Prediction import failed");
        }
    }

    // ================= FILE PICKER =================
    private File chooseFile() {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV Files", "*.csv")
        );
        return fc.showOpenDialog(null);
    }

    // ================= UI REFRESH FIX =================
    private void refreshUI() {


        AppData.studentList.setAll(new ArrayList<>(AppData.studentList));
        AppData.courseList.setAll(new ArrayList<>(AppData.courseList));
        AppData.predictionList.setAll(new ArrayList<>(AppData.predictionList));
    }

    // ================= ALERTS =================
    private void showSuccess(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Import Successful");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.show();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Import Failed");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.show();
    }
}