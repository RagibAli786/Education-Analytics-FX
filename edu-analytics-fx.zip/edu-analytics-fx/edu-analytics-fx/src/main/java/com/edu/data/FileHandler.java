package com.edu.data;

import com.edu.model.Student;
import com.edu.model.Course;
import com.edu.model.Prediction;

import java.io.*;
import java.util.List;

public class FileHandler {


    private static final String STUDENT_FILE = "students.csv";
    private static final String COURSE_FILE = "courses.csv";
    private static final String PREDICTION_FILE = "predictions.csv";

    // ================= STUDENTS =================

    public static void saveStudents(List<Student> students) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STUDENT_FILE))) {

            writer.write("Name,ID,Course,Grade,GPA,Semester");
            writer.newLine();

            for (Student s : students) {
                writer.write(
                        s.getName() + "," +
                                s.getId() + "," +
                                s.getCourse() + "," +
                                s.getGrade() + "," +
                                s.getGpa() + "," +
                                s.getSemester()
                );
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadStudents() {

        File file = new File(STUDENT_FILE);
        if (!file.exists()) return;

        AppData.studentList.clear();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            reader.readLine(); // skip header

            String line;
            while ((line = reader.readLine()) != null) {

                String[] p = line.split(",");

                AppData.studentList.add(new Student(
                        p[0], p[1], p[2], p[3],
                        Double.parseDouble(p[4]),
                        p[5]
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= COURSES =================

    public static void saveCourses(List<Course> courses) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(COURSE_FILE))) {

            writer.write("Course Name,Course Code,Avg Grade,Enrolled,Pass Rate");
            writer.newLine();

            for (Course c : courses) {
                writer.write(
                        c.getCourseName() + "," +
                                c.getCourseCode() + "," +
                                c.getAvgGrade() + "," +
                                c.getEnrolled() + "," +
                                c.getPassRate()
                );
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadCourses() {

        File file = new File(COURSE_FILE);
        if (!file.exists()) return;

        AppData.courseList.clear();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {

                String[] p = line.split(",");

                AppData.courseList.add(new Course(
                        p[0], p[1], p[2],
                        Integer.parseInt(p[3]),
                        Double.parseDouble(p[4])
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= PREDICTIONS =================

    public static void savePredictions(List<Prediction> predictions) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PREDICTION_FILE))) {

            writer.write("Student,Course,Predicted Grade,Confidence,Risk Level");
            writer.newLine();

            for (Prediction p : predictions) {
                writer.write(
                        p.getStudent() + "," +
                                p.getCourse() + "," +
                                p.getPredictedGrade() + "," +
                                p.getConfidence() + "," +
                                p.getRiskLevel()
                );
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadPredictions() {

        File file = new File(PREDICTION_FILE);
        if (!file.exists()) return;

        AppData.predictionList.clear();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {

                String[] p = line.split(",");

                AppData.predictionList.add(new Prediction(
                        p[0], p[1], p[2],
                        Double.parseDouble(p[3]),
                        p[4]
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}