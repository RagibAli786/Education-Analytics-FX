package com.edu;

import com.edu.data.FileHandler;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        System.out.println("=== LOADING DATA ===");

        FileHandler.loadStudents();
        FileHandler.loadCourses();
        FileHandler.loadPredictions();

        System.out.println("Students: " + com.edu.data.AppData.studentList.size());
        System.out.println("Courses: " + com.edu.data.AppData.courseList.size());
        System.out.println("Predictions: " + com.edu.data.AppData.predictionList.size());

        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/views/main.fxml")
        );

        Scene scene = new Scene(loader.load(), 1200, 800);

        scene.getStylesheets().add(
                getClass().getResource("/style.css").toExternalForm()
        );

        stage.setTitle("Edu Analytics");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}