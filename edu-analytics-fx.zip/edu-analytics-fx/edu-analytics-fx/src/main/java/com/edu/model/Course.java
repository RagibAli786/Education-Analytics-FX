package com.edu.model;

public class Course {

    private String courseName;
    private String courseCode;
    private String avgGrade;
    private int enrolled;
    private double passRate;

    public Course(String courseName, String courseCode, String avgGrade,
                  int enrolled, double passRate) {

        this.courseName = courseName;
        this.courseCode = courseCode;
        this.avgGrade = avgGrade;
        this.enrolled = enrolled;
        this.passRate = passRate;
    }

    // ===== GETTERS =====
    public String getCourseName() { return courseName; }
    public String getCourseCode() { return courseCode; }
    public String getAvgGrade() { return avgGrade; }
    public int getEnrolled() { return enrolled; }
    public double getPassRate() { return passRate; }

    // ===== OPTIONAL VALIDATION =====
    public boolean isValid() {

        return courseName != null && !courseName.isEmpty()
                && courseCode != null && !courseCode.isEmpty()
                && enrolled >= 0
                && passRate >= 0 && passRate <= 100;
    }
}