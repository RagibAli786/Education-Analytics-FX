package com.edu.controller;

import com.edu.data.AppData;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.shape.Circle;

public class DashboardController {

    @FXML private Label studentCountLabel;
    @FXML private Label courseCountLabel;
    @FXML private Label predictionCountLabel;

    @FXML private PieChart gradeChart;
    @FXML private Circle hole;

    @FXML
    public void initialize() {


        studentCountLabel.setText(String.valueOf(AppData.studentList.size()));
        courseCountLabel.setText(String.valueOf(AppData.courseList.size()));
        predictionCountLabel.setText(String.valueOf(AppData.predictionList.size()));

        // ===== PIE CHART =====
        PieChart.Data a = new PieChart.Data("A", 40);
        PieChart.Data b = new PieChart.Data("B", 25);
        PieChart.Data c = new PieChart.Data("C", 20);
        PieChart.Data d = new PieChart.Data("D", 10);
        PieChart.Data f = new PieChart.Data("F", 5);

        gradeChart.getData().addAll(a, b, c, d, f);
        gradeChart.setLabelsVisible(false);

        javafx.application.Platform.runLater(() -> {
            a.getNode().setStyle("-fx-pie-color: #4CAF50;");
            b.getNode().setStyle("-fx-pie-color: #2196F3;");
            c.getNode().setStyle("-fx-pie-color: #FFC107;");
            d.getNode().setStyle("-fx-pie-color: #FF9800;");
            f.getNode().setStyle("-fx-pie-color: #F44336;");
        });

        hole.toFront();
    }
}