package com.edu.controller;

import com.edu.data.AppData;
import com.edu.data.FileHandler;
import com.edu.model.Prediction;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;

import java.util.HashMap;
import java.util.Map;

public class PredictionController {

    @FXML private TextField studentField;
    @FXML private TextField courseField;
    @FXML private TextField confidenceField;

    @FXML private ComboBox<String> predictedGradeBox;
    @FXML private ComboBox<String> riskBox;

    @FXML private TableView<Prediction> tableView;

    @FXML private TableColumn<Prediction, String> studentColumn;
    @FXML private TableColumn<Prediction, String> courseColumn;
    @FXML private TableColumn<Prediction, String> gradeColumn;
    @FXML private TableColumn<Prediction, Double> confidenceColumn;
    @FXML private TableColumn<Prediction, String> riskColumn;

    @FXML private PieChart gradePieChart;

    @FXML
    public void initialize() {

        predictedGradeBox.getItems().addAll(
                "A","A-","B+","B","B-","C+","C","C-","D+","D","F"
        );

        riskBox.getItems().addAll("Low","Medium","High");

        studentColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getStudent()));

        courseColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getCourse()));

        gradeColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getPredictedGrade()));

        confidenceColumn.setCellValueFactory(d ->
                new SimpleDoubleProperty(d.getValue().getConfidence()).asObject());

        riskColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getRiskLevel()));

        tableView.setItems(AppData.predictionList);

        refreshUI();
    }

    // ================= SAVE =================
    @FXML
    public void saveRecord() {

        if (studentField.getText().isBlank()
                || courseField.getText().isBlank()
                || confidenceField.getText().isBlank()
                || predictedGradeBox.getValue() == null
                || riskBox.getValue() == null) {
            System.out.println("Fill all fields");
            return;
        }

        double conf;
        try {
            conf = Double.parseDouble(confidenceField.getText());
        } catch (Exception e) {
            System.out.println("Invalid confidence");
            return;
        }

        Prediction p = new Prediction(
                studentField.getText(),
                courseField.getText(),
                predictedGradeBox.getValue(),
                conf,
                riskBox.getValue()
        );

        AppData.predictionList.add(p);
        FileHandler.savePredictions(AppData.predictionList);

        refreshUI();
        clearForm();
    }

    // ================= DELETE =================
    @FXML
    public void deleteRecord() {

        Prediction selected = tableView.getSelectionModel().getSelectedItem();

        if (selected == null) return;

        AppData.predictionList.remove(selected);
        FileHandler.savePredictions(AppData.predictionList);

        refreshUI();
    }

    // ================= REFRESH =================
    public void refreshUI() {
        tableView.refresh();
        updatePieChart();
    }

    // ================= PIE CHART (FIXED TOOLTIP) =================
    private void updatePieChart() {

        gradePieChart.getData().clear();

        Map<String, Integer> map = new HashMap<>();

        for (Prediction p : AppData.predictionList) {
            map.put(
                    p.getPredictedGrade(),
                    map.getOrDefault(p.getPredictedGrade(), 0) + 1
            );
        }

        int total = AppData.predictionList.size();

        for (Map.Entry<String, Integer> entry : map.entrySet()) {

            String label = entry.getKey();
            int count = entry.getValue();

            double percent = total == 0 ? 0 : (count * 100.0 / total);

            PieChart.Data slice = new PieChart.Data(label, count);
            gradePieChart.getData().add(slice);


            slice.nodeProperty().addListener((obs, oldNode, newNode) -> {
                if (newNode != null) {

                    String tooltipText = label +
                            "\nCount: " + count +
                            "\nPercentage: " + String.format("%.2f", percent) + "%";

                    Tooltip.install(newNode, new Tooltip(tooltipText));
                }
            });
        }

        gradePieChart.setLabelsVisible(true);
    }

    // ================= CLEAR =================
    @FXML
    public void clearForm() {
        studentField.clear();
        courseField.clear();
        confidenceField.clear();
        predictedGradeBox.setValue(null);
        riskBox.setValue(null);
    }
}