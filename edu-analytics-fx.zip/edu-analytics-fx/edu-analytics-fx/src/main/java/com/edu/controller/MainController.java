package com.edu.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;

public class MainController {

    @FXML
    private StackPane contentArea;

    private Object currentController;

    private void load(String file) {
        try {
            String path = "/views/" + file;
            System.out.println("Loading: " + path);

            var url = getClass().getResource(path);

            if (url == null) {
                throw new RuntimeException("FXML NOT FOUND: " + path);
            }

            FXMLLoader loader = new FXMLLoader(url);
            Parent view = loader.load();

            // store controller (optional future use)
            currentController = loader.getController();

            contentArea.getChildren().setAll(view);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void initialize() {
        load("dashboard.fxml");
    }

    @FXML
    public void showDashboard() {
        load("dashboard.fxml");
    }

    @FXML
    public void showStudents() {
        load("student.fxml");
    }

    @FXML
    public void showCourses() {
        load("course.fxml");
    }

    @FXML
    public void showPredictions() {
        load("prediction.fxml");
    }

    @FXML
    public void showImport() {
        load("import.fxml");
    }
}