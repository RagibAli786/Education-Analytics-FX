package com.edu.model;

public class Student {

    private String name;
    private String id;
    private String course;
    private String grade;
    private double gpa;
    private String semester;

    public Student(String name, String id, String course,
                   String grade, double gpa, String semester) {
        this.name = name;
        this.id = id;
        this.course = course;
        this.grade = grade;
        this.gpa = gpa;
        this.semester = semester;
    }

    public double getGpa() {
        return gpa;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getCourse() {
        return course;
    }

    public String getGrade() {
        return grade;
    }

    public String getSemester() {
        return semester;
    }
}