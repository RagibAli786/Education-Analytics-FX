package com.edu.controller;

import com.edu.data.AppData;
import com.edu.data.FileHandler;
import com.edu.model.Student;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.*;

public class StudentController {

    @FXML private TextField nameField;
    @FXML private TextField idField;
    @FXML private TextField courseField;
    @FXML private TextField gpaField;
    @FXML private TextField semesterField;

    @FXML private ComboBox<String> gradeBox;

    @FXML private Label totalStudentsLabel;
    @FXML private Label avgGpaLabel;

    @FXML private TableView<Student> tableView;

    @FXML private TableColumn<Student, String> nameColumn;
    @FXML private TableColumn<Student, String> idColumn;
    @FXML private TableColumn<Student, String> courseColumn;
    @FXML private TableColumn<Student, String> gradeColumn;
    @FXML private TableColumn<Student, Double> gpaColumn;
    @FXML private TableColumn<Student, String> semesterColumn;

    @FXML private BarChart<String, Number> gpaChart;

    @FXML
    public void initialize() {

        gradeBox.setItems(FXCollections.observableArrayList(
                "A","A-","B+","B","B-","C+","C","C-","D+","D","F"
        ));

        nameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
        idColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getId()));
        courseColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getCourse()));
        gradeColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getGrade()));
        semesterColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getSemester()));
        gpaColumn.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getGpa()).asObject());

        tableView.setItems(AppData.studentList);

        refreshUI();
    }

    // ================= SAVE =================
    @FXML
    public void saveRecord() {

        if (nameField.getText().isBlank()
                || idField.getText().isBlank()
                || courseField.getText().isBlank()
                || semesterField.getText().isBlank()
                || gradeBox.getValue() == null
                || gpaField.getText().isBlank()) {
            System.out.println("Fill all fields");
            return;
        }

        double gpa;
        try {
            gpa = Double.parseDouble(gpaField.getText());
        } catch (Exception e) {
            System.out.println("Invalid GPA");
            return;
        }

        Student s = new Student(
                nameField.getText(),
                idField.getText(),
                courseField.getText(),
                gradeBox.getValue(),
                gpa,
                semesterField.getText()
        );

        AppData.studentList.add(s);
        FileHandler.saveStudents(AppData.studentList);

        refreshUI();
        clearForm();
    }

    // ================= DELETE =================
    @FXML
    public void deleteRecord() {

        Student selected = tableView.getSelectionModel().getSelectedItem();

        if (selected == null) return;

        AppData.studentList.remove(selected);
        FileHandler.saveStudents(AppData.studentList);

        refreshUI();
    }

    // ================= IMPORT (FIXED) =================
    @FXML
    public void importData() {

        // clear first (important)
        AppData.studentList.clear();

        // reload from file
        FileHandler.loadStudents();

        // refresh UI instantly
        refreshUI();
    }

    // ================= REFRESH =================
    public void refreshUI() {
        tableView.refresh();
        updateStats();
        updateChart();
    }

    // ================= CHART (FIXED ALIGNMENT + TOOLTIP) =================
    private void updateChart() {

        gpaChart.getData().clear();

        // disable animation BEFORE rendering (fixes shifting bug)
        gpaChart.setAnimated(false);

        CategoryAxis xAxis = (CategoryAxis) gpaChart.getXAxis();
        xAxis.setAnimated(false);
        xAxis.setTickLabelRotation(90);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("GPA");

        for (Student s : AppData.studentList) {
            series.getData().add(
                    new XYChart.Data<>(s.getName(), s.getGpa())
            );
        }

        gpaChart.getData().add(series);

        javafx.application.Platform.runLater(() -> {

            gpaChart.applyCss();
            gpaChart.layout();

            for (XYChart.Data<String, Number> data : series.getData()) {

                if (data.getNode() != null) {

                    Tooltip.install(
                            data.getNode(),
                            new Tooltip(data.getXValue() + " : " + data.getYValue())
                    );

                    data.getNode().setStyle("-fx-bar-fill: #87CEEB;");
                }
            }
        });
    }

    // ================= STATS =================
    private void updateStats() {

        totalStudentsLabel.setText(String.valueOf(AppData.studentList.size()));

        double avg = AppData.studentList.stream()
                .mapToDouble(Student::getGpa)
                .average()
                .orElse(0.0);

        avgGpaLabel.setText(String.format("%.2f", avg));
    }

    // ================= CLEAR =================
    @FXML
    public void clearForm() {
        nameField.clear();
        idField.clear();
        courseField.clear();
        gpaField.clear();
        semesterField.clear();
        gradeBox.setValue(null);
    }
}