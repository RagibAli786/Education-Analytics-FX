package com.edu.model;

public class Prediction {

    private String student;
    private String course;
    private String predictedGrade;
    private double confidence;
    private String riskLevel;

    public Prediction(String student, String course,
                      String predictedGrade,
                      double confidence,
                      String riskLevel) {

        this.student = student;
        this.course = course;
        this.predictedGrade = predictedGrade;
        this.confidence = confidence;
        this.riskLevel = riskLevel;
    }

    // ===== GETTERS =====
    public String getStudent() { return student; }
    public String getCourse() { return course; }
    public String getPredictedGrade() { return predictedGrade; }
    public double getConfidence() { return confidence; }
    public String getRiskLevel() { return riskLevel; }

    // ===== OPTIONAL SAFETY HELPERS =====

    public boolean isValid() {

        return student != null && !student.isEmpty()
                && course != null && !course.isEmpty()
                && predictedGrade != null && !predictedGrade.isEmpty()
                && confidence >= 0 && confidence <= 100
                && riskLevel != null && !riskLevel.isEmpty();
    }
}