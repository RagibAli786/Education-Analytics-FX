package com.edu.data;

import com.edu.model.Student;
import com.edu.model.Course;
import com.edu.model.Prediction;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AppData {

    public static ObservableList<Student> studentList =
            FXCollections.observableArrayList();

    public static ObservableList<Course> courseList =
            FXCollections.observableArrayList();

    public static ObservableList<Prediction> predictionList =
            FXCollections.observableArrayList();
}