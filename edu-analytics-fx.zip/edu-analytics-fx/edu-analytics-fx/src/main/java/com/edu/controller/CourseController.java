package com.edu.controller;

import com.edu.data.AppData;
import com.edu.model.Course;
import com.edu.data.FileHandler;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.CategoryAxis;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;

import java.util.HashMap;
import java.util.Map;

public class CourseController {

    @FXML private TextField courseNameField;
    @FXML private TextField courseCodeField;

    @FXML private ComboBox<String> avgGradeBox;

    @FXML private TextField enrolledField;
    @FXML private TextField passRateField;

    @FXML private BarChart<String, Number> enrollmentChart;

    @FXML private TableView<Course> tableView;

    @FXML private TableColumn<Course, String> nameColumn;
    @FXML private TableColumn<Course, String> codeColumn;
    @FXML private TableColumn<Course, String> avgGradeColumn;
    @FXML private TableColumn<Course, Integer> enrolledColumn;
    @FXML private TableColumn<Course, Double> passRateColumn;

    @FXML
    public void initialize() {

        // ===== TABLE =====
        nameColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getCourseName()));

        codeColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getCourseCode()));

        avgGradeColumn.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getAvgGrade()));

        enrolledColumn.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getEnrolled()).asObject());

        passRateColumn.setCellValueFactory(d ->
                new SimpleDoubleProperty(d.getValue().getPassRate()).asObject());

        tableView.setItems(AppData.courseList);

        // ===== GRADE DROPDOWN FIX =====
        avgGradeBox.setItems(FXCollections.observableArrayList(
                "A", "A-",
                "B+", "B", "B-",
                "C+", "C", "C-",
                "D+", "D",
                "F"
        ));

        updateChart();
    }

    // ================= CHART =================
    private void updateChart() {

        enrollmentChart.getData().clear();

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Enrolled Students");

        for (Course c : AppData.courseList) {
            series.getData().add(
                    new XYChart.Data<>(c.getCourseName(), c.getEnrolled())
            );
        }

        enrollmentChart.getData().add(series);

        javafx.application.Platform.runLater(() -> {


            enrollmentChart.setAnimated(false);

            CategoryAxis xAxis = (CategoryAxis) enrollmentChart.getXAxis();
            xAxis.setAnimated(false);
            xAxis.setTickLabelRotation(90);
            xAxis.setTickLabelGap(10);

            enrollmentChart.applyCss();
            enrollmentChart.layout();

            for (XYChart.Data<String, Number> data : series.getData()) {

                if (data.getNode() != null) {

                    Tooltip.install(
                            data.getNode(),
                            new Tooltip(data.getXValue() + " : " + data.getYValue())
                    );

                    data.getNode().setStyle("-fx-bar-fill: #87CEEB;");
                }
            }
        });
    }

    // ================= SAVE =================
    @FXML
    public void saveRecord() {

        if (courseNameField.getText().isEmpty()
                || courseCodeField.getText().isEmpty()
                || avgGradeBox.getValue() == null
                || enrolledField.getText().isEmpty()
                || passRateField.getText().isEmpty()) {

            System.out.println("Fill all fields first");
            return;
        }

        Course c = new Course(
                courseNameField.getText(),
                courseCodeField.getText(),
                avgGradeBox.getValue(),
                Integer.parseInt(enrolledField.getText()),
                Double.parseDouble(passRateField.getText())
        );

        AppData.courseList.add(c);
        FileHandler.saveCourses(AppData.courseList);

        updateChart();
        clearForm();
    }

    // ================= DELETE =================
    @FXML
    public void deleteRecord() {

        Course selected = tableView.getSelectionModel().getSelectedItem();

        if (selected == null) {
            System.out.println("No record selected");
            return;
        }

        AppData.courseList.remove(selected);
        FileHandler.saveCourses(AppData.courseList);

        updateChart();
    }

    // ================= CLEAR =================
    @FXML
    public void clearForm() {

        courseNameField.clear();
        courseCodeField.clear();
        enrolledField.clear();
        passRateField.clear();

        avgGradeBox.setValue(null);
    }
}